var GA = {
    population:[],
    mutationRate: 0.1,
}
function random(a,b){
    return a+Math.random() * (b - a);
}
function randomInt(a, b){
    return Math.floor(random(a,b));
}

function randomChoose(array){
    return array[randomInt(0,array.length)];
}

GA.run = function(size,maxGen){
    GA.population = GA.newPopulation(size);
    for (t= 0; t<maxGen;t++){
        console.log("=======generation" , t, "========");
        GA.population = GA.reproduction(GA.population);
        GA.dump();
    }
}
var fitnessCompare = (c1,c2) =>c1.fitness - c2.fitness;
GA.newPopulation = function(size){
    var newPop[];
    for(var i = 0;i<size;i++){

    }
}

KeyGA.crossover = function(c1,c2){
    var cutIdx = random(0,c1.chromosome.length);
    var head = c1.chromosome
}